
const input=document.getElementById("imageInput");
const preview=document.getElementById("preview");
if(input){
 input.addEventListener("change",()=>{
  preview.innerHTML="";
  const f=input.files[0];
  if(f){
   const img=document.createElement("img");
   img.style.maxWidth="100%";img.style.maxHeight="180px";img.style.marginTop="15px";img.style.borderRadius="10px";
   img.src=URL.createObjectURL(f);preview.appendChild(img);
  }
 });
}
